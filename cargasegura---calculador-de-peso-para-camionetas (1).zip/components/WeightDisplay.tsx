
import React from 'react';

interface WeightDisplayProps {
  current: number;
  max: number;
}

const WeightDisplay: React.FC<WeightDisplayProps> = ({ current, max }) => {
  const percentage = Math.min((current / max) * 100, 100);
  const isOver = current > max;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-slate-500 text-sm font-medium uppercase tracking-wider">Peso Total</h2>
          <div className={`text-5xl font-bold ${isOver ? 'text-red-600' : 'text-slate-900'}`}>
            {current} <span className="text-2xl font-normal text-slate-400">kg</span>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-400 mb-1">Capacidad Máxima</p>
          <p className="font-semibold text-slate-700">{max} kg</p>
        </div>
      </div>

      <div className="relative h-4 w-full bg-slate-100 rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all duration-500 ease-out ${
            isOver ? 'bg-red-500' : percentage > 80 ? 'bg-orange-500' : 'bg-emerald-500'
          }`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      
      {isOver && (
        <p className="mt-3 text-red-600 text-sm font-medium flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          ¡Exceso de carga! Has superado la capacidad de tu vehículo.
        </p>
      )}
    </div>
  );
};

export default WeightDisplay;
