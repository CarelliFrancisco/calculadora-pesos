
import React from 'react';
import { BoxType } from '../types';

interface BoxSelectorProps {
  box: BoxType;
  quantity: number;
  onChange: (id: string, newQty: number) => void;
  onDelete?: (id: string) => void;
}

const BoxSelector: React.FC<BoxSelectorProps> = ({ box, quantity, onChange, onDelete }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-slate-300 transition-all group">
      <div className="flex items-center gap-4">
        <div className={`${box.color} w-12 h-12 rounded-lg flex items-center justify-center text-2xl shadow-inner relative`}>
          {box.icon}
          {box.isCustom && onDelete && (
            <button 
              onClick={() => onDelete(box.id)}
              className="absolute -top-2 -left-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-red-600"
              title="Eliminar caja"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          )}
        </div>
        <div>
          <h3 className="font-bold text-slate-800">{box.name}</h3>
          <p className="text-sm text-slate-500">{box.weight} kg / unidad</p>
        </div>
      </div>
      
      <div className="flex items-center gap-3">
        <button 
          onClick={() => onChange(box.id, Math.max(0, quantity - 1))}
          className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 text-slate-600 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
          </svg>
        </button>
        
        <span className="w-8 text-center text-xl font-bold text-slate-700">{quantity}</span>
        
        <button 
          onClick={() => onChange(box.id, quantity + 1)}
          className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 text-white shadow-md transition-all active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default BoxSelector;
